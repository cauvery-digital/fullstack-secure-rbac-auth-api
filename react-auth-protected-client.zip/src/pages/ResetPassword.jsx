function ResetPassword() {
  return (
    <div>
      <h2>Reset Password</h2>
      <p>Implement password reset here...</p>
    </div>
  );
}
export default ResetPassword;
function VerifyEmail() {
  return (
    <div>
      <h2>Email Verification</h2>
      <p>Email verification in progress...</p>
    </div>
  );
}

export default VerifyEmail;
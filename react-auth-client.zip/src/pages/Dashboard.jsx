function Dashboard() {
  return (
    <div>
      <h2>Welcome to your dashboard</h2>
      <p>Secure content goes here...</p>
    </div>
  );
}

export default Dashboard;
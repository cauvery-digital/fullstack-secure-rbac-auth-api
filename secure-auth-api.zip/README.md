# Secure Express Auth API

A full-featured authentication backend built with Express + MongoDB.

## Features
- JWT login/logout with refresh tokens (httpOnly cookie)
- Email verification
- Password reset via email
- Role-based access control
- Agenda for scheduled jobs (e.g. auto-delete unverified accounts)
- Helmet, CORS, HPP, XSS protection
- Validation using express-validator
- Swagger API docs

## Setup
1. Clone the repo
2. Run: npm install
3. Rename `.env.example` → `.env`
4. Fill in your MongoDB URI, email, and JWT secrets
5. Start the dev server:
   ```
   node server.js
   ```
6. Visit Swagger Docs:
   ```
   http://localhost:5000/api-docs
   ```
